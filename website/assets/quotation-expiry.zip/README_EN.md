# Quotation expiry evidence package

This package preserves the result of the iEWR 7.0.6 first experiment. It contains the generated tool, tests, input, output, and recorded checks. The English agent assignment was run in a fresh extracted distribution and a new Codex CLI session. See the site's EN/RU case for conditions and the Try page for the assignment.

Extract into a separate folder. From that folder, run:

```sh
python3 project/artifacts/first-experiment/check_quotes.py project/source/first-experiment/quotes.csv project/artifacts/first-experiment/output.csv --as-of 2026-11-05
python3 -m unittest discover -s project/artifacts/first-experiment -v
```

These commands run the produced solution. To regenerate it through AI, use the iEWR distribution and the Try assignment. Python 3 and its standard library are sufficient for this tool. CHECKS.json records the separate verification; PROVENANCE.json binds the included experiment files to their preserved originals. Five tests and six output rows belong to this particular task.
