# Quotation expiry experiment

From the environment root:

```sh
python3 project/artifacts/first-experiment/check_quotes.py project/source/first-experiment/quotes.csv project/artifacts/first-experiment/output.csv --as-of 2026-11-05
python3 -m unittest discover -s project/artifacts/first-experiment -v
```

Python 3 standard library only. Dates must be exact ASCII YYYY-MM-DD real calendar dates. Equality is valid; only later dates expire. Invalid dates affect only their own row. CSV values, order, duplicate ids, and additional columns are retained; CSV quoting and line endings may be normalized. Missing fields are padded; surplus fields receive extra_N headers. Input and output must differ. Output is overwritten on success.

Method basis: supplied FPF C.39:4.1 (lines 81986–81997) made the requested receiving result and its distinguishing observation the basis of sufficiency. Reused SW-01 v1.5 user-result, behavior, operation-contract, and checking guidance, including independently specified expected answers. DMG supplied the local strict date parser, CSV mapping, and boundary/CLI checks using Python expertise. No new shared MP method or environment change was needed. Initial broad source reads were truncated; only received portions and the subsequently complete checking fragment (1320–1338) were relied upon, not hidden text.

Actual checks: five unittest cases passed (checks.txt), covering final-day equality, before/after boundaries, invalid/missing dates, leap dates, strict format, required/invalid CLI date, full six-row CSV preservation, unchanged input bytes, same-file rejection, duplicate ids, quoted fields, and continued processing after a missing field. The actual command produced output.csv: Q1 expired; Q2/Q3 valid; Q4/Q5/Q6 invalid. No known requirement violations remain.

Limits: local synthetic experiment, not production assurance. Requires readable UTF-8 CSV with unique id and valid_until headers and no preexisting status column. Malformed CSV syntax and file-level errors stop the command; invalid date cells do not. Loads the input into memory; large files, concurrent writers, and interrupted output writes were not tested. Output writes are not atomic. Released environment files were not edited; all created files are in the requested project directories. No network, installation, or publishing was used.
