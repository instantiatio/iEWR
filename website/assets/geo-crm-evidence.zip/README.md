# GEO CRM case evidence

Application 1.2.3-demo; iEWR 7.0.0; report date 2026-11-05. The Russian-language PDF contains the detailed report and all 12 screenshots. Two representative original images are included separately for the website. Data are synthetic.

The test log and JUnit XML record the report run. This package is evidence, not an application-source distribution. Full application startup and scenario conditions are in the PDF report; original source identity is in PROVENANCE.json.

To repeat the selected independent arithmetic check with Python 3:

```sh
python3 check_arithmetic.py
```

scenario.json is a purpose-selected subset of the original report evidence sufficient for this exact check: input dates/amounts and both series of daily balances. It produces arithmetic-check.json. Base minimum: RUB 770,000. Delay of all client receipts by 30 days: minimum RUB -910,000; first cash gap 2026-11-23.

Приложение 1.2.3-demo, среда iEWR 7.0.0. PDF содержит полный русский отчёт и 12 кадров. Отдельно включены два исходных изображения. Для сверки арифметики выполните команду выше. Это свидетельства опыта, а не поставка исходного кода CRM.
