from pathlib import Path
import json
from datetime import date,timedelta
from decimal import Decimal as D
r=Path(__file__).resolve().parent;v=json.loads((r/'scenario.json').read_text());start=date.fromisoformat(v['inputs']['settings']['start_date']);report={}
for delay,key in [(0,'baseline'),(30,'delay30')]:
 flows=v['inputs']['flows'];balance=D(v['inputs']['settings']['opening_cash']);minimum=balance;gap=None
 for day in v[key]['stress']['days']:
  current=date.fromisoformat(day['date']);inc=D(0);out=D(0)
  for f in flows:
   due=max(date.fromisoformat(f['expected_date']),start)
   if f['kind']=='receipt':due+=timedelta(days=delay)
   if due==current:
    if f['kind']=='receipt':inc+=D(f['amount'])
    else:out+=D(f['amount'])
  assert balance==D(day['opening']);balance+=inc-out
  assert inc==D(day['inflow']) and out==D(day['outflow']) and balance==D(day['closing'])
  minimum=min(minimum,balance)
  if balance<0 and gap is None:gap=str(current)
 assert minimum==D(v[key]['stress']['minimum']) and gap==v[key]['stress']['first_gap']
 report[key]={'daily_rows':91,'minimum':str(minimum),'first_gap':gap,'independent_loop':'PASS'}
(r/'arithmetic-check.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
